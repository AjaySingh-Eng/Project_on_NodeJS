//require mongoose 
const mongoose=require('mongoose');

// we need mongoose to connect with my DB
mongoose.connect('mongodb://127.0.0.1/codeial_development');

const db=mongoose.connection;

db.on("error", console.error.bind(console, "error connecting to database"));

db.once('open', function(){
    console.log('Connected to Database :: MongoDB');
});

module.exports=db;