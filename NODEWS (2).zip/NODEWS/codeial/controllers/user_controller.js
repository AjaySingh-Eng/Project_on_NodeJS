const User = require("../models/user")

// module.exports.profile = function(req, res) {
//     if (req.cookies.user_id) {
//         User.findById(req.cookies.user_id, function(err, user) {
//             if (user) {
//                 return res.render('user_profile', {
//                     title: 'user_profile',
//                     user: user // Pass the user object to the view
//                 });
//             }
//             return res.redirect('/users/sign-in');
//         });
//     } else {
//         return res.redirect('/users/sign-in');
//     }
// };

module.exports.profile = async function(req, res) {
    try {
        if (req.cookies.user_id) {
            const user = await User.findById(req.cookies.user_id);
            if (user) {
                return res.render('user_profile', {
                    title: 'user_profile',
                    user_profile: user // Pass the user object to the view
                });
            }
            return res.redirect('/users/sign-in');
        } else {
            return res.redirect('/users/sign-in');
        }
    } catch (err) {
        console.error('Error in profile:', err);
        return res.redirect('/'); // Handle the error gracefully
    }
};



// module.exports.createSession = function(req, res){
//     return res.redirect('/');
// }


//     if(req.cookies.user_id){
//         User.findById(req.cookies.user_id, function(err, user){
//             if(user){
//                 return res.render('user_profile', {
//                     title:'user_profile',
//                     user:user
//                 })
//             }
//             return res.redirect('/users/sign-in');
//         });
//     }else{
//         return res.redirect('/users/sign-in');
//     }
// }  

// render the sign in page
// module.exports.signup=function(req,res){
//     return res.render('user_sign_up',{
//         title:'Codeial | Sign Up'
//     })
// }

// // render the sign up page
// module.exports.signin=function(req,res){
//     return res.render('user_sign_in',{
//         title:'Codeil | Sign In'
//     })
// }

// render the sign up page
module.exports.signUp = function(req, res){
    if(req.isAuthenticated()){
        return res.redirect('/users/profile');
    }
    return res.render('user_sign_up', {
        title: "Codeial | Sign Up"
    })
}

// render the sign in page
module.exports.signIn = function(req, res){
    if(req.isAuthenticated()){
        return res.redirect('/users/profile');
    }
    return res.render('user_sign_in', {
        title: "Codeial | Sign In"
    })
}


//get the sign up data
 
module.exports.create = async function(req, res) {
    try {
        // Check if password matches confirm_password
        if (req.body.password != req.body.confirm_password) {
            return res.redirect('back');
        }

        // Find user by email
        const user = await User.findOne({ email: req.body.email });

        // If user doesn't exist, create a new user
        if (!user) {
            await User.create(req.body);
            return res.redirect('/users/sign-in');
        } else {
            // User already exists
            return res.redirect('back');
        }
    } catch (err) {
        console.error('Error in signing up:', err);
        return res.redirect('back');
    }
};

// // sign in and create a session for the user
// module.exports.createSession=function(req, res){
//     // steps to authenticate

//     // find the user
//        User.findOne({email: req.body.email}, function(err, user){

//         if(err){
//             console.log('error in finding user in signing in'); return}
//             // handle user found

//             if(user){
//                 //handle passowrd which doesn't match
//                 if(user.password !=req.body.password){
//                     return res.redirect('back');
//                 }

//                 // handle session creation
//                 res.cookie('user_id', user.id);
//                 return res.redirect('/users/profile');

//             }else{
//                 //handle user not find
//                 return res.redirect('back');
//             }
//         });
// }

// sign in and create a session for the user
module.exports.createSession=function(req, res){
    return res.redirect('/'); //assuming that user has sign_in and pass this

}

module.exports.destroySession=function(req, res){
    req.logout(function(err) {
        if (err) {
            // Handle error
            console.error('Error logging out:', err);
            return next(err); // Pass the error to the next middleware
        }
        // If logout is successful, redirect the user or do other operations
        res.redirect('/'); // Redirect to the home page
    });
    
    // return res.redirect('/');
}