module.exports.home=function(req, res){
     console.log(req.cookies);
     res.cookie('user_id', 25);
    // return res.end('<h1>Express is up for Codeial</h1>'); -- after setting up the home ejs for the browser inside views file this line to omit.
    return res.render('home',{
        title: "Home"
    });
}

// module.exports.actionName=function(req, res){
//     return res.end('<h2>My Name is Ajay from controller</h2>');
// };