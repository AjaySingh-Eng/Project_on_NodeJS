// Import the 'express' module and assign it to the variable 'express'.
const express=require("express");

// adding the cookie in cookieParser liberary

const cookieParser=require('cookie-parser');

// Create an instance of the Express application and assign it to the variable 'app'.
const app=express();

// Define the port number 8000 and assign it to the variable 'port'.
const port=8080;

const expressLayouts=require('express-ejs-layouts');

const db=require('./config/mongoose');

//used for session cookie
const session=require('express-session');
const passport=require('passport');
const passportLocal=require('./config/passport-local-strategy');
const MongoStore = require('connect-mongo');
const sassMiddleware=require('node-sass-middleware');

app.use(sassMiddleware({
  src: './assets/scss',
  dest: './assets/css',
  debug: true,
  outputStyle: 'expanded',
  prefix: '/css'
}));
app.use(express.urlencoded());
app.use(cookieParser());

app.use(express.static('./assets'));

//middleware
app.use(expressLayouts);

// extract style and script from sub pages into the layout
app.set('layout extractStyles', true);
app.set('layout extractStyles', true);
//const postRoutes= require('./routes/post');

//use express router
// app.use('/', require('./routes'));

//view engine setup
app.set('view engine', 'ejs');
app.set('views', './views');


// mongo store is used to store the session cookie in the mongoDB database
app.use(session({
    name: 'codeial',
    // todo change the secret before deployment in production mode
    secret: 'Ajay Singh write something here',
    saveUninitialized: false,
    resave: false,
    cookie: {
        maxAge: (1000*60*100)
    },
    // store: new MongoStore({
    //     mongooseConnection: db,
    //     autoRemove: 'disabled'
    // },
    //  function(err){
    //     console.log(err || 'connect-mongodb setup ok');
    // }
    
}));

app.use(passport.initialize());
app.use(passport.session());

app.use(passport.setAuthenticatedUser);


// app.use('/api/posts', postRoutes);

// use express router
app.use('/', require('./routes'));

// Start the Express application to listen for incoming requests on the specified port.
// The 'listen' method takes the port number and a callback function as arguments.
app.listen(port, function(err){
   

     // If an error occurs during the server startup process, execute the following block.
    if(err){
        

        // Use string interpolation to log the error message along with a descriptive text.
        console.log(`Error in running the server:${err}`);

         // Exit the callback function early to prevent further execution.
        return;
    }

    // If the server starts successfully, log a success message along with the port number.
    console.log(`Server is up and running on port:${port}`);
});
