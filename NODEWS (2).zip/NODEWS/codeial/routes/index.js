 const express=require('express');
 
 //create a route handlers.
 const router=express.Router();

 const homeController=require('../controllers/home_controller');


// if loaded it will show in cmd prmt
 console.log('Router loaded');

 router.get('/', homeController.home);
 router.use('/users', require('./users'));

 // for any futher routes access from here
 // router.use('/routerName', require('./router))

//  router.get('/action', homeController.actionName);

 module.exports=router;