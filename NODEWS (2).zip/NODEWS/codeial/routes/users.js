const express = require('express');
const router = express.Router();
const passport = require('passport');

const usersController = require('../controllers/user_controller');

// Route to render the users page
// router.get('/', (req, res) => {
//     res.render("users", { title: "users" });
// });

// Route to render the user profile page
router.get('/profile', passport.checkAuthentication, usersController.profile);

// Route to render the sign-in page
router.get('/sign-in', usersController.signIn);

// Route to render the sign-up page
router.get('/sign-up', usersController.signUp);

// Route to handle user registration
router.post('/create', usersController.create);

// Route to handle user authentication
// router.post('/create-session', (req, res, next) => {
//     passport.authenticate('local', (err, user, info) => {
//         if (err) {
//             console.error('Error in authentication:', err);
//             return next(err); // Pass the error to the next middleware
//         }
//         if (!user) {
//             // Redirect to sign-in page if authentication fails
//             return res.redirect('/users/sign-in');
//         }
//         // If authentication succeeds, log in the user
//         req.logIn(user, (err) => {
//             if (err) {
//                 console.error('Error in logging in user:', err);
//                 return next(err);
//             }
//             // Redirect to user profile page upon successful login
//             return res.redirect('/users/profile');
//         });
//     })(req, res, next); // Invoke the Passport authentication middleware
// });

router.post('/create-session', passport.authenticate(
    'local', 
    {failureRedirect: '/users/sign-in'},
), usersController.createSession);

router.get('/sign-out', usersController.destroySession);
module.exports = router;
